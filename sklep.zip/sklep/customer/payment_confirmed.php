<?php
session_start();
 require_once "connection.php";
 
 $id=$_GET['id'];

 $sql="SELECT * FROM product WHERE id='$id' AND status='1' ";
 $query=$dbhandler->query($sql);
 $r=$query->fetch(PDO::FETCH_ASSOC);
 if(!empty($r))
{   
    
}
    
 if(isset($_POST['submit']))
    
 ?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Złożono zamowienie!</title>
</head>

<body>
    <div class="box-area">
        <div class="banner">
            <h1>Dziękujemy! <br/>Przekazaliśmy twoje zamówienie do realizacji!</h1>
        </div>
</div>
<style>
*{
    font-family: Arial;
}
    </style>
</body>

</html>