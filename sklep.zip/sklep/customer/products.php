<?php
 session_start();
 require_once "connection.php"; 
 $empty='';$flag=0;
 $cat_id=$_GET['id'];
 $_SESSION['CAT_ID'] = $cat_id;
     
    if(isset($_POST['submit']))
    {
        
        $product_id = $_POST['product_id'] ;
        $name = $_POST['name'];
    
    }

 $sql="SELECT * FROM product WHERE categories_id='$cat_id' AND status='1' ";
 $query=$dbhandler->query($sql);
 $r=$query->fetchAll(PDO::FETCH_ASSOC);
    if(!empty($r))
    {
    }
    else{
        $empty="dopisz do końca linku '?id=1'!";
        $flag=1;
    }
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Produkty</title>
</head>

<body>
    <link rel="stylesheet" type="text/css" href="../css/style_products.css" />
    <div class="box-area">
        <header>
           <h1>Sklep</h1>
        </header>
        
        <div class="content">
        <div class="error">
              <p>
                  <?php 
                  if($flag==1)
                  {  echo $empty;
                     die();
                  }
                  if($flag==2)
                  {
                    echo $msg;
                    $flag=0;
                  }
                  ?>
               </p>
         </div>
         
         <?php 
         if ($flag==0){
         echo '<table border="1" style="width:75%;">
              <tr>
                  <th colspan="4">Produkty</th>
              </tr>';
              $i = 0;
             foreach($r as $row){
                echo '<tr>
                <td><img src="../css/images/product/'.$row['image'].'" width="200" height="200"/></td>
                <td>Nazwa :'.$row['name'].'<br/>Cena :'.$row['price'].'<br/></td>
                <td><a href="purchase.php?id='. $row['id'].'">Kup teraz</a></td>
                <td>
                
                 
                </td>
               
                <input type="hidden" name="product_id" value="'.$row['id'].'">
                <input type="hidden" name="name" value="'.$row['name'].'">
              
             
                </form>
                </tr>';
                       
            }
             }   
             echo '</table>';  ?>
             <br/>
        </div>

</div>

<style>
*{
    margin:0;
    padding:0;
    font-family: Arial;
}
body{
    text-align: center;
}
.wrapper{
    width: 1170px;
    margin: 0 auto;
}
header{
    height: 100px;
    background: #454545;
    width:100%;
    z-index: 12;
    position: fixed;
}
ul{
    float: right;
    line-height: 100px;
}
ul li{
    display: inline-block;
}
ul li a{
    text-decoration: none;
    color: #fff;
    letter-spacing: 4px;
    font-size: 30px;
    margin: 0 10px;
    border: 3px solid transparent;
    transition: 0.6s ease;
}
ul li a:hover{
    background-color: #fff;
    color:#7d7d7d;

}
ul li.active a{
    background-color: #fff;
    color: #000;
}

.content{
    width: 100%;
    height: 1000px;
    position: relative;
    top: 100px;
    letter-spacing: 2px;
    font-size: 30px;
    background-image:linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5));
    -webkit-background-size: cover;
    background-size: 100% auto;
    background-position: center center;
}
.content table {
    margin-left: auto;
    margin-right: auto;
    border: 1px solid white;
    background-color: #ffffff30;
    backdrop-filter: blur(20px);
    border-radius: 10px;
    box-shadow: 0 10px;
}
.content table td,th{
    color: #ffffff;
    letter-spacing: 1px;
    font-size: 1.5em;
}
.content table a{
    
    text-decoration: none;
    color: #fff;
    letter-spacing: 4px;
    font-size: 30px;    
    border: 3px solid transparent;
    transition: 0.6s ease;
}
.content table input[type="submit"],input[type="number"]{
    
    text-decoration: none;
    color:black;
    letter-spacing: 2px;
    font-size: 22px;    
    border: 3px solid transparent;
    transition: 0.6s ease;
}

.content table a:hover,input[type="submit"]:hover{
   
    background-color: #DC143C;
    color: #fff;
}

.error p{
    color: #ffffff;
    letter-spacing: 1px;
    font-size: 1.5em;

}


</style>
</body>

</html>